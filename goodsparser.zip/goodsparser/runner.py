from scrapy.crawler import CrawlerProcess
from scrapy.settings import Settings
from goodsparser import settings
from goodsparser.spiders.lmpl import LmplSpider



if __name__ == '__main__':
    crawler_settings = Settings()
    crawler_settings.setmodule(settings)

    process = CrawlerProcess(settings=crawler_settings)
    search_item = 'lampa'
    process.crawl(LmplSpider, search=search_item)

    process.start()

