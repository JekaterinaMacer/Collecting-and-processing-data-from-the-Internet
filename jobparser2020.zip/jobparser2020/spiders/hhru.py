import scrapy
from scrapy.http import HtmlResponse
from jobparser2020.items import Jobparser2020Item

class HhruSpider(scrapy.Spider):
    name = 'hhru'
    allowed_domains = ['hh.ru']
    start_urls = ['https://hh.ru/search/vacancy?area=1&fromSearchLine=true&st=searchVacancy&text=Python&from=suggest_post']

    def parse(self, response: HtmlResponse):
        vacancies_links = response.xpath("//span/a[contains(@class, 'bloko-link')]/@href").extract()
        for link in vacancies_links:
            yield response.follow(link, callback=self.vacancy_parse)
        next_page = response.xpath("//a[contains(@class, 'HH-Pager-Controls-Next')]/@href").extract_first()
        if next_page:
            yield response.follow(next_page, callback=self.parse)
        else:
            return

    def vacancy_parse(self, response: HtmlResponse):
        name = response.xpath("//h1/text()").extract_first()
        salary = response.xpath("//p[@class='vacancy-salary']//text()").extract()
        vacancy_link = response.url
        domain = 'hh.ru'
        yield Jobparser2020Item(item_name=name, item_salary=salary, item_link=vacancy_link, item_source=domain)
        return

