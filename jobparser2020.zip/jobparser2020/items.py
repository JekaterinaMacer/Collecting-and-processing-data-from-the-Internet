import scrapy


class Jobparser2020Item(scrapy.Item):
    # define the fields for your item here like:
    _id = scrapy.Field()
    item_name = scrapy.Field()
    item_salary = scrapy.Field()
    item_link = scrapy.Field()
    item_source = scrapy.Field()
